<?php 
/*
session_start();
if (empty($_POST)) {
require "twilio-php-master/Services/Twilio.php";

$AccountSid = "mushibishi";
$AuthToken = "mushibishi";
$http =new Services_Twilio_TinyHttp('http://api.twilio.com',array('curlopts' => array(CURLOPT_SSL_VERIFYPEER => false
)));
$client = new Services_Twilio($AccountSid, $AuthToken,'2010-04-01',$http);
$code =strtoupper(substr(md5(uniqid()), 0,5));
if ($client->account->sms_messages->create("126-979-56682",+21694969657,"votre code est:".$code)) {
	echo "hhhhhh";
}
else
{echo "ppppppppppppp";}
}


/******************************************************************************


session_start();
if (empty($_POST)) {

    
        include "../Twilio/Rest/client.php";

// Send an SMS using Twilio's REST API and PHP
$sid = "ACf2848a4e670bd1f89a7950a2ab56b6f1"; // Your Account SID from www.twilio.com/console
$token = "30ae4afea5b41208843acddd7d105c0c"; // Your Auth Token from www.twilio.com/console
//$code =strtoupper(substr(md5(uniqid()), 0,5));
$client = new Client1($sid, $token);
$message = $client->messages->create(
  '+12697956682', // Text this number
  array(
    'from' => '+21694969657', // From a valid Twilio number
    'body' => 'Hello from hhhh!'
  )
);

print $message->sid;
}
/***********************************************************
$from=$_POST['email'];
$tel=$_POST['tel'];
$message="hhhh";
$carrier="txtlocal.co.uk";





$message=wordwrap($message,70);
$header = $from;
$subject='from submission';
$to=$tel.'@'.$carrier;
$result =mail($to, $subject,$message,$header);
echo "send to ".$to;




/******************************************************

	// Authorisation details.
	$username = "ahmed.bensaid@esprit.tn";
	$hash = "4d44405c0ba2eac3ac9fe9e967c08cb6da740c87753f5dc83683c1b7edfce7b7";

	// Config variables. Consult http://api.txtlocal.com/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "API Test"; // This is who the message appears to be from.
	$numbers = "21694969657"; // A single number or a comma-seperated list of numbers
	$message = "This is a test message from the PHP API script.";
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.txtlocal.com/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);



    
    	// Account details
    	$apiKey = urlencode('4d44405c0ba2eac3ac9fe9e967c08cb6da740c87753f5dc83683c1b7edfce7b7');
    	
    	// Message details
    	$numbers = array(21694969657,21694969657);
    	$sender = urlencode('Jims Autos');
    	$message = rawurlencode('This is your message');
     
    	$numbers = implode(',', $numbers);
     
    	// Prepare data for POST request
    	$data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
     
    	// Send the POST request with cURL
    	$ch = curl_init('https://api.txtlocal.com/send/');
    	curl_setopt($ch, CURLOPT_POST, true);
    	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    	$response = curl_exec($ch);
    	curl_close($ch);
    	
    	// Process your response here
    	echo $response;
 













*/



include "../entities/client.php";
include "../core/client.php";
if (isset($_POST['nom']) and isset($_POST['prenom']) and isset($_POST['tel']) and isset($_POST['email']))
{
          $tel=$_POST['tel'];
          $email=$_POST['email'];
          $nom=$_POST['nom'];
          $prenom=$_POST['prenom'];
            $clientEC=new ClientC();
             $tel=$clientEC->fogottel($tel);
             $nom=$clientEC->fogotnom($nom);
             $prenom=$clientEC->fogotprenom($prenom);
             $mail=$clientEC->existencemail($email);
             if($mail){

                if($nom){
                    if($prenom){
                        if($tel){

                        $listeClient=$clientEC->afficherClient($email);
                        foreach($listeClient as $row){
                           $n=$row['nom'];
                           $p=$row['prenom'];
                           $pwd=$row['password'];
                            $message =" Mr ou Mrs:".$n."-".$p." votre Mot de Passe est ==>".$pwd."";
                            
                        mail($email,"Mot de passe oublié B&B",$message,"From: BandB.storeB@gmail.com");
                                header('Location: login.php');
                                    }

                                }
                                else{echo " 
                            <script type='text/javascript'>
                            alert('veuillez verifier tel ');
                               window.location.replace(\"http://localhost/client11/views/login.php\"); 
                              
                              </script>";}
                             }
                        else{
                            echo " 
                            <script type='text/javascript'>
                            alert('veuillez verifier prenom ');
                               window.location.replace(\"http://localhost/client11/views/login.php\"); 
                              
                              </script>"
                        ;}
                        }
                    else{echo " 
                            <script type='text/javascript'>
                            alert('veuillez verifier nom ');
                               window.location.replace(\"http://localhost/client11/views/login.php\"); 
                              
                              </script>";}
                    }
             else{echo " 
                            <script type='text/javascript'>
                            alert('veuillez verifier email ');
                               window.location.replace(\"http://localhost/client11/views/login.php\"); 
                              
                              </script>";}




}




 ?>