<?php
include "../config.php";

$confirm = $_GET['code'];
$db = config::getConnexion();
$sql = "UPDATE client SET code ='null' , active='1' WHERE code='$confirm'";
$result = $db->query($sql) or die(mysqli_error());
if($result)
{
echo 
" 
							<script type='text/javascript'>
		             		alert('Votre compte est maintenant actif. Vous pouvez maintenant revenir en arrière et avoir votre compte en B&B ');
		                       window.location.replace(\"http://localhost/client11/views/login.php\"); 
		                      
		                      </script>";
}
else
{
echo "Some error occur.";
}
?>